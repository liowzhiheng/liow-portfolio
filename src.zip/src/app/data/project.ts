import { Project } from '../core/models/project';


export const PROJECTS: Project[] = [


    {
        id: 'immerse-vr',

        title:
            'Mixed Reality Horror Game',

        subtitle:
            'Eye blinking detection and pattern recognition VR experience',

        description:
            'A mixed reality horror game developed using Unity and Pico 4 Enterprise. The project combines AI-based pattern recognition with eye blinking interaction to create an immersive horror experience.',

        video:
            'https://youtube.com',

        screenshots: [

            '/assets/projects/immerse-1.png',

            '/assets/projects/immerse-2.png',

            '/assets/projects/immerse-3.png'

        ],

        technologies: [

            'Unity',

            'C#',

            'Pico 4',

            'ONNX',

            'OpenCV',

            'TensorFlow'

        ]

    },



    {
        id: 'jomteam',

        title:
            'JomTeam',

        subtitle:
            'Sports buddy finder web application',

        description:
            'A web platform that helps users create and join sports activities with real-time communication features.',

        video: '',

        screenshots: [

        ],

        technologies: [

            'Angular',

            'PHP',

            'MySQL',

            'JavaScript'

        ]

    }



];